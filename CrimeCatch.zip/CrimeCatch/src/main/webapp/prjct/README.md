# No Crime
App for visualizing and repor

###Backend###

Click [https://github.com/deepdeev/nocrime](https://github.com/deepdeev/nocrime) for the backend repo.
There are two methods for getting started with this repo.
